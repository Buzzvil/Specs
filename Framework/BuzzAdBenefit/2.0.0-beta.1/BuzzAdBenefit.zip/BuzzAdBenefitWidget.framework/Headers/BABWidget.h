//
//  BABWidget.h
//  BABWidget
//
//  Created by seohyun kwak on 2019/12/09.
//  Copyright © 2019 Buzzvil. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BABUserProfile;

NS_ASSUME_NONNULL_BEGIN

@interface BABWidget: NSObject

- (BOOL)isLoggedIn;
- (void)loginWithAppGroup:(NSString *)keychainAccessGroupId;

@end

NS_ASSUME_NONNULL_END
