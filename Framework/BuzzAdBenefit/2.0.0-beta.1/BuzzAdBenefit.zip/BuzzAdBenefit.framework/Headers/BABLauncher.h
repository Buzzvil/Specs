//
//  BABLauncher.h
//  BAB
//
//  Created by Jaehee Ko on 30/01/2019.
//  Copyright © 2019 Buzzvil. All rights reserved.
//

NS_ASSUME_NONNULL_BEGIN

@class BABAd;
@protocol BABLauncher;

typedef enum {
  BABLauncherStatusPageLoadFailed = 0,
  BABLauncherStatusLandingConditionNotSatisfied,
  BABLauncherStatusDeepLinkOpened
} BABLauncherStatus;

@class BABLaunchInfo;

@protocol BABLauncherEventDelegate <NSObject>

- (void)launcher:(id<BABLauncher>)launcher didLandingSucceededResponse:(BABLaunchInfo *)launchInfo;

- (void)launcher:(id<BABLauncher>)launcher didLandingFailureResponse:(BABLaunchInfo *)launchInfo status:(BABLauncherStatus)status;

- (void)launcher:(id<BABLauncher>)launcher didOpeningExternalBrowserResponse:(BABLaunchInfo *)launchInfo;

@end

@protocol BABLauncher <NSObject>

- (void)openUrl:(NSURL *)url object:(BABLaunchInfo *)object userInfo:(nullable NSDictionary *)userInfo;

- (void)openUrl:(NSURL *)url object:(BABLaunchInfo *)object userInfo:(nullable NSDictionary *)userInfo delegate:(id<BABLauncherEventDelegate>)delegate;

@end

NS_ASSUME_NONNULL_END
