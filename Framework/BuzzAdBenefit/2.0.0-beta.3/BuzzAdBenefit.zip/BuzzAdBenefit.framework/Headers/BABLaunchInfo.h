#import <Foundation/Foundation.h>

@interface BABLaunchInfo : NSObject

@property (nonatomic, copy, readonly) NSString *title;
@property (nonatomic, assign, readonly) long durationInMillis;
@property (nonatomic, assign, readonly) long reward;

@property (nonatomic, assign, readonly) BOOL shouldLandingExternalBrowser;

@property (nonatomic, copy, readonly) id object;

- (instancetype) initWithTitle:(NSString *)title
                      duration:(long)durationInMillis
                        reward:(long)reward
  shouldLandingExternalBrowser:(BOOL)shouldLandingExternalBrowser
                        object:(id)object;

@end
