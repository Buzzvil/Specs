//
//  Header.h
//  BAB
//
//  Created by Jaehee Ko on 25/07/2019.
//  Copyright © 2019 Buzzvil. All rights reserved.
//

#import <BuzzAdBenefitWebInterface/BABWebInterface.h>

static NSUInteger const BuzzAdBenefitWebInterfaceVersion = 2;
static NSString *const BuzzAdBenefitWebInterfaceName = @"BuzzAdBenefitNative";
