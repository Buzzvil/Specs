//
//  BuzzAdBenefitInterstitial.h
//  BuzzAdBenefitInterstitial
//
//  Created by Jaehee Ko on 21/02/2019.
//  Copyright © 2019 Buzzvil. All rights reserved.
//

#import <BuzzAdBenefitInterstitial/BABInterstitialAdHandler.h>
#import <BuzzAdBenefitInterstitial/BABInterstitialConfig.h>
