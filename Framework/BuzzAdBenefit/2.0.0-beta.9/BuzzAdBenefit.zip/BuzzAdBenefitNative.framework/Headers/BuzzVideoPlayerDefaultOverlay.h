//
//  BuzzVideoPlayerDefaultOverlay.h
//  BABNative
//
//  Created by Jaehee Ko on 17/01/2020.
//  Copyright © 2020 Buzzvil. All rights reserved.
//

#import <BuzzAdBenefitNative/BuzzAdBenefitNative.h>

NS_ASSUME_NONNULL_BEGIN

@interface BuzzVideoPlayerDefaultOverlay : BuzzVideoPlayerOverlay

@end

NS_ASSUME_NONNULL_END
