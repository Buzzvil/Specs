#import <UIKit/UIKit.h>
#import <BuzzAdBenefit/BABArticle.h>

NS_ASSUME_NONNULL_BEGIN

@interface BABFeedConfig : NSObject

@property (nonatomic, copy, readonly) NSString *unitId;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) Class headerViewClass;
@property (nonatomic, strong) Class adViewHolderClass;
@property (nonatomic, strong) Class articleViewHolderClass;
@property (nonatomic, strong) Class errorViewHolderClass;
@property (nonatomic, assign) BOOL articlesEnabled;
@property (nonatomic, strong, nullable) NSArray<BABArticleCategoryName> *articleCategories;
@property (nonatomic, assign) CGFloat separatorHeight;
@property (nonatomic, strong) UIColor *separatorColor;
@property (nonatomic, assign) CGFloat separatorHorizontalMargin;

- (instancetype)initWithUnitId:(NSString *)unitId;

@end

NS_ASSUME_NONNULL_END
