#import <Foundation/Foundation.h>

@interface BuzzPointAppConfig : NSObject

@property (nonatomic, assign, readonly) int minRedeemAmount;
@property (nonatomic, assign, readonly) BOOL autoRedeem;
@property (nonatomic, assign, readonly) int pointRate;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@end
