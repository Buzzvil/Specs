#import <Foundation/Foundation.h>
#import "BABOrientation.h"

@protocol BABRewardedVideoPresenterInputProtocol;
@protocol BABRewardedVideoAdInternalDelegate;
@class BABRewardedAd;
@class BABRewardedVideoAdMetadata;
@class BABRewardedVideoAdTracker;

@protocol BABRewardedVideoPresenterOutputProtocol <NSObject>

@required
- (void)setupVideoPlayerView;

- (void)setupCreativeInfoViewOverPlayer;

- (void)setupCreativeInfoViewBelowPlayer;

- (void)setupCreativeInfoWebView;

- (void)setupWebView;

- (void)showCreativeInfoView;

- (void)hideCreativeInfoView;

- (void)hideBannerCreativeInfoView;

- (void)showCreativeInfoWebViewWithUrl:(NSString *)url;

- (void)openLandingPageWithUrl:(NSString *)url;

- (void)openAdchoicePageWithUrl:(NSString *)url;

@end

@protocol BABRewardedVideoPresenterInputProtocol <NSObject>

@required
@property (nonatomic, strong) id<BABRewardedVideoPresenterOutputProtocol> view;
@property (nonatomic, strong) id<BABRewardedVideoAdInternalDelegate> delegate;

- (void)didInitView;

- (void)requestLanding;

- (void)didCompleteLanding;

- (void)requestAdChoiceLanding;

- (void)didStartPlayingVideo;

- (void)didProgressMinimumTime:(NSTimeInterval)time;

- (void)didCompletePlayingVideo;

- (void)didCloseVideoAd;

@end

@interface BABRewardedVideoPresenter : NSObject <BABRewardedVideoPresenterInputProtocol>

- (instancetype)initWithRewardedAd:(BABRewardedAd *)rewardedAd
                   videoAdMetadata:(BABRewardedVideoAdMetadata *)videoAdMetadata
                       orientation:(BABOrientation)deviceOrientation
                    videoAdTracker:(BABRewardedVideoAdTracker *)videoAdTracker;

@end
