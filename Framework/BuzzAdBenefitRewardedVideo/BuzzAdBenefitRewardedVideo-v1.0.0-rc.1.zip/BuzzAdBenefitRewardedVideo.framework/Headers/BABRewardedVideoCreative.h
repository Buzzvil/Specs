#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum {
  BABRewardedVideoCreativeTypeDirectVideo = 0,
  BABRewardedVideoCreativeTypeVastVideo,
} BABRewardedVideoCreativeType;

typedef enum {
  BABRewardedVideoTemplateTypeUnknown = 0,
  BABRewardedVideoTemplateTypeVertical,
  BABRewardedVideoTemplateTypeHorizontal,
} BABRewardedVideoTemplateType;

@interface BABRewardedVideoCreative : NSObject

@property (nonatomic, assign, readonly) BABRewardedVideoCreativeType type;
@property (nonatomic, assign, readonly) BABRewardedVideoTemplateType templateType;

@property (nonatomic, copy, readonly) NSString *title;
@property (nonatomic, copy, readonly) NSString *body;
@property (nonatomic, copy, readonly) NSString *callToAction;
@property (nonatomic, copy, readonly) NSString *thumbnailUrl;
@property (nonatomic, copy, readonly) NSString *iconUrl;

@property (nonatomic, copy, readonly) NSString *vastTag;

@property (nonatomic, copy, readonly) NSString *clickUrl;
@property (nonatomic, copy, readonly) NSString *adchoiceUrl;
@property (nonatomic, copy, readonly) NSString *vastClickThrough;
@property (nonatomic, copy, readonly) NSArray<NSString *> *vastClickTrackings;

@property (nonatomic, copy, readonly) NSString *adnetworkCampaignId;

- (instancetype)initWithType:(BABRewardedVideoCreativeType)type
                templateType:(BABRewardedVideoTemplateType)templateType
                       title:(NSString *)title
                        body:(NSString *)body
                callToAction:(NSString *)callToAction
                thumbnailUrl:(NSString *)thumbnailUrl
                     iconUrl:(NSString *)iconUrl
                     vastTag:(NSString *)vastTag
                    clickUrl:(NSString *)clickUrl
                 adchoiceUrl:(NSString *)adchoiceUrl
            vastClickThrough:(NSString *)vastClickThrough
          vastClickTrackings:(NSArray<NSString *> *)vastClickTrackings
         adnetworkCampaignId:(NSString *)adnetworkCampaignId;

@end

NS_ASSUME_NONNULL_END
