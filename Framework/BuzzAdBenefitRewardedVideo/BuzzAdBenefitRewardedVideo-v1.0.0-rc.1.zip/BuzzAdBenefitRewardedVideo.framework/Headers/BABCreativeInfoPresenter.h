#import <Foundation/Foundation.h>

@protocol BABCreativeInfoPresenterInputProtocol;
@protocol BABRewardedVideoPresenterInputProtocol;
@class BABRewardedVideoCreative;
@class BABRewardedVideoPresenter;

@protocol BABCreativeInfoPresenterOutputProtocol <NSObject>

@required
@property (nonatomic, strong) id<BABCreativeInfoPresenterInputProtocol> _presenter;

- (void)setPresenter:(id<BABCreativeInfoPresenterInputProtocol>)presenter;

- (void)showCreativeInfoWithCreative:(BABRewardedVideoCreative *)creative;

@end

@protocol BABCreativeInfoPresenterInputProtocol <NSObject>

@required
@property (nonatomic, strong) id<BABCreativeInfoPresenterOutputProtocol> view;
@property (nonatomic, strong) id<BABRewardedVideoPresenterInputProtocol> event;

- (void)didInitView;

- (void)didClickAdchoiceButton;

- (void)didClickCallToActionButton;

@end

@interface BABCreativeInfoPresenter : NSObject <BABCreativeInfoPresenterInputProtocol>

- (instancetype)initWithCreative:(BABRewardedVideoCreative *)creative;

@end
