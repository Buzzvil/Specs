#import <UIKit/UIKit.h>

@protocol BuzzVideoPlayerViewProtocol;

NS_ASSUME_NONNULL_BEGIN

@interface BABVideoPlayerViewController : UIViewController <BuzzVideoPlayerViewProtocol>

- (void)attachComponentToOverlay:(UIView *)component;

@end

NS_ASSUME_NONNULL_END
