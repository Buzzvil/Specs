#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BABCloseDialogDelegate <NSObject>

- (void)CloseDialogDidDismissOnNegative;

- (void)CloseDialogDidDismissOnPositive;

@end

@interface BABCloseDialogViewController : UIViewController

@property (nonatomic, weak) id<BABCloseDialogDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
