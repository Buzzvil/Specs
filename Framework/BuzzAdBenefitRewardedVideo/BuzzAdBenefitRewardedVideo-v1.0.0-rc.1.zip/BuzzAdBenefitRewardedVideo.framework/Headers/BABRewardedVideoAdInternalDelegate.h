#import <Foundation/Foundation.h>

@protocol BABRewardedVideoAdInternalDelegate <NSObject>

- (void)rewardedVideoAdDidOpen;

- (void)rewardedVideoAdDidStartPlaying;

- (void)rewardedVideoAdDidCompletePlaying;

- (void)rewardedVideoAdDidClose;

- (void)rewardedVideoAdWillLeaveApplication;

- (void)reardedVideoAdDidReceiveAdClick;

- (void)rewardedVideoAdDidEarnReward:(int)reward;

@end
