#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class BABRewardedVideoAdRequest;

NS_ASSUME_NONNULL_BEGIN

@protocol BABRewardedVideoAdDelegate <NSObject>

- (void)rewardedVideoAdDidReceiveAd;

- (void)rewardedVideoAdDidOpen;

- (void)rewardedVideoAdDidStartPlaying;

- (void)rewardedVideoAdDidCompletePlaying;

- (void)rewardedVideoAdDidClose;

- (void)rewardedVideoAdWillLeaveApplication;

- (void)reardedVideoAdDidReceiveAdClick;

- (void)rewardedVideoAdDidEarnReward:(int)reward;

- (void)rewardedVideoAdDidFailToLoadWithError:(NSError *)error;

@end

@interface BABRewardedVideoAd : NSObject

@property (nonatomic, weak) id<BABRewardedVideoAdDelegate> delegate;

+ (NSString *)sdkVersion;

- (instancetype)initWithAppId:(NSString *)appId
                       userId:(NSString *)userId;

- (void)initializeWithCallback:(void (^)(void))onSuccess
                     onFailure:(void (^)(NSError *error))onFailure;

- (BOOL)isReady;

- (void)loadWithRequest:(BABRewardedVideoAdRequest *)request;

- (void)presentFromViewController:(nonnull UIViewController *)viewController;

@end

NS_ASSUME_NONNULL_END
