#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@protocol BABRewardedVideoWebViewDelegate

- (void)closeWebView;

@end

@interface BABRewardedVideoWebView : UIView

@property (nonatomic, weak) id<BABRewardedVideoWebViewDelegate> delegate;

- (void)loadRequestWithUrl:(NSString *)url;

- (void)disableCloseButton;

- (void)setRoundedCorner:(UIRectCorner)corner;

@end
