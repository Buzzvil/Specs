#import <Foundation/Foundation.h>
#import "BABOrientation.h"
#import "BABVideoLayoutType.h"

NS_ASSUME_NONNULL_BEGIN

// TODO : VideoPlayer에서 제어할 로직과 RV용 Feature 분리
@protocol BuzzVideoPlayerPresenterProtocol;
@protocol BABRewardedVideoPresenterInputProtocol;
@protocol VideoPlayerEventDelegate;

@class BABRewardedVideoCreative;
@class BABRewardedVideoAdMetadata;
@class BABRewardedVideoPresenter;
@class VideoPlayer;

@protocol BuzzVideoPlayerViewProtocol <NSObject>

@required
@property (nonatomic, strong) id<BuzzVideoPlayerPresenterProtocol> _presenter;

// RV Feature
- (void)setPresenter:(id<BuzzVideoPlayerPresenterProtocol>)presenter;

- (void)setupLayoutWithLayoutType:(BABVideoLayoutType)layoutType;

- (void)setLayoutWithLayoutType:(BABVideoLayoutType)layoutType;

- (void)setThumbnailImageWithUrl:(NSString *)url;

- (void)showCloseDialog;

- (void)dismissView;

// VideoPlayer Feature

- (void)showThumbnailView;

- (void)hideThumbnailView;

- (void)updateTimerWithTime:(NSTimeInterval)mediaTime duration:(NSTimeInterval)totalTime;

- (void)showTimerDone;

- (void)showPlayButton;

- (void)hidePlayButton;

- (void)showPauseButton;

- (void)hidePauseButton;

- (void)showSoundOnButton;

- (void)hideSoundOnButton;

- (void)showSoundOffButton;

- (void)hideSoundOffButton;

- (void)showOverlay;

- (void)hideOverlay;

@end

@protocol BuzzVideoPlayerPresenterProtocol <NSObject, VideoPlayerEventDelegate>

@required
@property (nonatomic, strong) id<BuzzVideoPlayerViewProtocol> view;
@property (nonatomic, strong) id<BABRewardedVideoPresenterInputProtocol> event;
@property (nonatomic, strong) VideoPlayer *player;
@property (nonatomic, strong) BABRewardedVideoCreative *creative;

// RV Feature

- (void)didInitView;

- (void)didClickCloseButton;

- (void)didClickDismissButton;

- (void)didDismissCloseDialog;
// Video Feature

- (void)didClickPlayButton;

- (void)didClickPauseButton;

- (void)didClickSoundOnButton;

- (void)didClickSoundOffButton;

- (void)didClickFullscreenButton;

- (void)didClickCollapseButton;

- (void)didClickOverlay;

@end

@interface BABVideoPlayerPresenter : NSObject <BuzzVideoPlayerPresenterProtocol>

- (instancetype)initWithPlayer:(VideoPlayer *)player
                      creative:(BABRewardedVideoCreative *)creative
                   orientation:(BABOrientation)deviceOrientation
               videoAdMetadata:(BABRewardedVideoAdMetadata *)videoAdMetadata;

@end

NS_ASSUME_NONNULL_END
