
typedef enum {
  BABOrientationLandscape = 0,
  BABOrientationPortrait
} BABOrientation;
