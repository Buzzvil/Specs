#import <Foundation/Foundation.h>

@class BABRewardedVideoCreative;
@class BuzzCreative;

@interface BABRewardedVideoCreativeMapper : NSObject

- (BABRewardedVideoCreative *)transformWithCreative:(BuzzCreative *)creative;

@end
