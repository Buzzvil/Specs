
typedef enum {
  BABVideoLayoutTypeLandscapeWithInfoOverlay = 0,
  BABVideoLayoutTypePortraitWithInfoOverlay,
  BABVideoLayoutTypeLandscapeFullscreen,
  BABVideoLayoutTypePortraitFullscreen,
  BABVideoLayoutTypeLandscapeWithVerticalVideo,
  BABVideoLayoutTypePortraitWithHorizontalVideo,
} BABVideoLayoutType;
