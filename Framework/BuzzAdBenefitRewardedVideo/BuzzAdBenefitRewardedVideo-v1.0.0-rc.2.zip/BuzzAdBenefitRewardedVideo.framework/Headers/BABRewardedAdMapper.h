#import <Foundation/Foundation.h>

@class BABRewardedVideoCreativeMapper;
@class BABRewardedAd;
@class BuzzAd;

@interface BABRewardedAdMapper : NSObject

- (instancetype)initWithCreativeMapper:(BABRewardedVideoCreativeMapper *)mapper;

- (BABRewardedAd *)transformWithAd:(BuzzAd *)ad;

- (NSArray<BABRewardedAd *> *)transformWithAds:(NSArray<BuzzAd *> *)ads;

@end
