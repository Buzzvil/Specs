#import <Foundation/Foundation.h>
#import "BABRewardedVideoCreative.h"

NS_ASSUME_NONNULL_BEGIN

@interface BABRewardedAd : NSObject

@property (nonatomic, assign) NSInteger id;
@property (nonatomic, assign) NSInteger actionReward;
@property (nonatomic, assign) NSInteger landingReward;
@property (nonatomic, copy, readonly) NSString *payload;
@property (nonatomic, copy, readonly) NSDictionary *extra;
@property (nonatomic, copy) BABRewardedVideoCreative *creative;
@property (nonatomic, copy) NSArray<NSString *> *clickTrackings;
@property (nonatomic, copy) NSArray<NSString *> *impressionTrackings;

- (instancetype)initWithId:(NSInteger)id
              actionReward:(NSInteger)actionReward
             landingReward:(NSInteger)landingReward
                   payload:(NSString *)payload
                     extra:(NSDictionary *)extra
                  creative:(BABRewardedVideoCreative *)creative
            clickTrackings:(NSArray<NSString *> *)clickTrackings
       impressionTrackings:(NSArray<NSString *> *)impressionTrackings;

@end

NS_ASSUME_NONNULL_END
