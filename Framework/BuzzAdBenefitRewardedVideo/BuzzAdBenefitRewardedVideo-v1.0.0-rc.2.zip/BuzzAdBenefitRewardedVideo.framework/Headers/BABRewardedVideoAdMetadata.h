#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BABRewardedVideoAdMetadata : NSObject

@property (nonatomic, assign, readonly) NSTimeInterval minimumTime;
@property (nonatomic, copy, readonly) NSArray<NSString *> *impressionTrackings;
@property (nonatomic, copy, readonly) NSArray<NSString *> *clickTrackings;
@property (nonatomic, copy, readonly) NSString *postbackUrl;
@property (nonatomic, copy, readonly) NSString *sessionId;
@property (nonatomic, assign, readonly) BOOL *webViewMode;

- (instancetype)initWithMinimumTime:(NSTimeInterval)minimumTime
                impressionTrackings:(NSArray<NSString *> *)impressionTrackings
                     clickTrackings:(NSArray<NSString *> *)clickTrackings
                        postbackUrl:(NSString *)postbackUrl
                          sessionId:(NSString *)sessionId
                        webViewMode:(BOOL)webViewMode;
@end

NS_ASSUME_NONNULL_END
