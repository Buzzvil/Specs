#import <UIKit/UIKit.h>
#import "BABOrientation.h"

@protocol BABCreativeInfoPresenterOutputProtocol;

NS_ASSUME_NONNULL_BEGIN

@interface BABCreativeInfoView: UIView <BABCreativeInfoPresenterOutputProtocol>

- (instancetype)initWithOrientation:(BABOrientation)orientation;

- (void)setupHorizontalEndCardStyle;

- (void)setupHorizontalSmallBannerStyle;

- (void)setupVerticalEndCardStyle;

- (void)setupVerticalSmallBannerStyle;

@end

NS_ASSUME_NONNULL_END
