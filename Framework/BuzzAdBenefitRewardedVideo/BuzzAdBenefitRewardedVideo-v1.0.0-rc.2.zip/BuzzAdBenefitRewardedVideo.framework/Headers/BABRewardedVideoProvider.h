#import <Foundation/Foundation.h>

@class BuzzAdUseCase;
@class BuzzVideoAdUseCase;
@class BuzzAdRequest;
@class BuzzVideoAdMetadataRequest;
@class AuthUseCase;
@class BuzzSessionUseCase;
@class BuzzSessionRequest;
@class BuzzEventUseCase;
@class BABRewardedAd;
@class BABRewardedVideoAdMetadata;
@class BABRewardedAdMapper;
@class BABRewardedVideoCreativeMapper;
@class BABRewardedVideoAdMetadataMapper;
@class BABRewardedVideoAdTracker;
@class VideoPlayer;

NS_ASSUME_NONNULL_BEGIN

@interface BABRewardedVideoProvider : NSObject

- (instancetype)initWithBaseUrl:(NSString *)baseUrl;

- (BuzzAdUseCase *)getAdUseCase;

- (BuzzVideoAdUseCase *)getVideoAdUseCase;

- (AuthUseCase *)getAuthUseCase;

- (BuzzSessionUseCase *)getSessionUseCase;

- (BuzzEventUseCase *)getEventUseCase;

- (BuzzSessionRequest *)getSessionRequestWithAdId:(NSString *)adId
                                            appId:(NSString *)appId
                                           userId:(NSString *)userId;

- (BuzzAdRequest *)getAdRequestWithAdId:(NSString *)adId
                             sessionKey:(NSString *)sessionKey
                                 unitId:(NSString *)unitId
                              birthYear:(NSInteger)birthYear
                                 gender:(NSString *)gender;

- (BuzzVideoAdMetadataRequest *)getVideoAdMetadataRequestWithRewardedAd:(BABRewardedAd *)rewardedAd
                                                             baseReward:(NSInteger)baseReward
                                                                 userId:(NSString *)userId;

- (BABRewardedAdMapper *)getRewardedAdMapper;

- (BABRewardedVideoCreativeMapper *)getCreativeMapper;

- (BABRewardedVideoAdMetadataMapper *)getVideoAdMetadataMapper;

- (BABRewardedVideoAdTracker *)getVideoAdTrackerWithVideoAdMetadata:(BABRewardedVideoAdMetadata *)videoAdMetadata;

- (VideoPlayer *)getVideoPlayer;

- (NSString *)getAppKeyFromPlist;

@end

NS_ASSUME_NONNULL_END
