#import <UIKit/UIKit.h>

@protocol BABRewardedVideoPresenterOutputProtocol;
@protocol BABRewardedVideoAdInternalDelegate;
@class BABRewardedAd;
@class BABRewardedVideoAdTracker;
@class BABRewardedVideoAdMetadata;
@class VideoPlayer;

@protocol BABRewardedVideoAdInternalDelegate;

@interface BABRewardedVideoViewController : UIViewController <BABRewardedVideoPresenterOutputProtocol>

- (instancetype)initWithRewardedAd:(BABRewardedAd *)rewardedAd
                adInternalDelegate:(id<BABRewardedVideoAdInternalDelegate>)adInternalDelegate
                   videoAdMetadata:(BABRewardedVideoAdMetadata *)videoAdMetadata
                    videoAdTracker:(BABRewardedVideoAdTracker *)videoAdTracker
                            player:(VideoPlayer *)player;

@end
