#import <Foundation/Foundation.h>

@class BABRewardedVideoAdMetadata;
@class BuzzEventUseCase;

@interface BABRewardedVideoAdTracker : NSObject

- (instancetype)initWithEventUseCase:(BuzzEventUseCase *)useCase
                     videoAdMetadata:(BABRewardedVideoAdMetadata *)videoAdMetadata;

- (void)onImpress;

- (void)onClick;

- (void)onTimeChanged:(NSTimeInterval)time;

@end
