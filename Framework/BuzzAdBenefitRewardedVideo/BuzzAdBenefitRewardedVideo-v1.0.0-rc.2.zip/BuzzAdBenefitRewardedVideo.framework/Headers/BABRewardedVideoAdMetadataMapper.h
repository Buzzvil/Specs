#import <Foundation/Foundation.h>

@class BABRewardedVideoAdMetadata;
@class BABRewardedAd;
@class BuzzVideoAdMetadata;

@interface BABRewardedVideoAdMetadataMapper : NSObject

- (BABRewardedVideoAdMetadata *)transformWithBuzzVideoAdMetadata:(BuzzVideoAdMetadata *)videoAdMetadata
                                                              ad:(BABRewardedAd *)ad
                                                        duration:(NSTimeInterval)duration;

@end
