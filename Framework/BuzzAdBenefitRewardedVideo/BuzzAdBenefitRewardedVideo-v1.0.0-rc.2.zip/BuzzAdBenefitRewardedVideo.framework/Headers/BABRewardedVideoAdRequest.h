#import <Foundation/Foundation.h>

@interface BABRewardedVideoAdRequest : NSObject

@property(nonatomic, assign) int birthyear;

@property(nonatomic, assign) NSString *gender;

- (instancetype)initWithBirthyear:(int)birthyear
                           gender:(NSString *)gender;

@end
